<?php

class RapportResultaat {
  private $_vak = ""; 
  private $_rapport = ""; 
  private $_resultaten = array(); 
  
  public function BerekenGemiddelde() {
    
	}
  
  public function BerekenLetter() {
    
	}
  
  public function BerekenCommentaar() {
    
	}
?>