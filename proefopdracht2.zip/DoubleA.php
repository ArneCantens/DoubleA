<?php

require_once(__DIR__ . "/Student.php");

class DoubleA {
	private $_student = array();
	
	public function Login(string $email, string $wachtwoord) {

	}
  
  public function Logout() {

	}	

?>